---
layout: post
title: 다시 읽고 싶은 글 (계속 업데이트)
category: etc
tags: [자료, 북마크]
comments: true
---

# 저장하고 다시 읽고 싶은 글


## 학습
- [프로그래밍 입문자를 위한 몇 가지 조언 - 한날](http://blog.hannal.com/2016/01/how-to-study-programming/)
- [무엇을 프로그래밍 할 것인가](http://agile.egloos.com/5854608)
- [다양한 학습 사이트들](https://github.com/honux77/practice/wiki/learn)
- [어려운 것을 쉽게 배우는 방법](http://www.moreagile.net/2016/02/learning-new-stuff.html)
  - 1단계 : 일단 만들기, 샘플코드 쌓기, 반복, 무엇을 모르는지 파악하기,
  - 2단계 : 난관에 도전하기
  - 3단계 : 뭔가 만들어 보기
- [학습 조언 - 윤지수](https://github.com/nigayo/education/blob/master/learning/afterWhite.md)
- [초보 웹 개발자를 위하여 - 정호영](https://github.com/honux77/practice/wiki/web-developer)
- [한 눈에 개발 보기 - 개발읽어주는 남자](https://brunch.co.kr/@imagineer/58)
- [웹개발자 기준 비전공자 신입으로서 전공자한테 안 밀리고 살아남는 법.tip](http://okky.kr/article/372485)

## 기타
- [slideShare 북마크 자료들](https://www.slideshare.net/HyunjooLEE38/clipboards/read-again)

## git
- [Git을 이용한 협업 워크플로우 배우기](http://blog.appkr.kr/learn-n-think/comparing-workflows/)
